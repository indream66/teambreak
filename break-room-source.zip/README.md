# BREAK ROOM 團拆控制台

GitHub Pages 版本提供轉盤、多獎抽選、分隊、骰子／擲筊規則、音效、球卡 OCR 與直播外框。

## GitHub Pages 建置

使用 Node.js 22.13 以上版本。

```sh
npm ci
npm run build:pages
```

將程式碼及產出的 `docs/` 一起提交。GitHub Settings → Pages 設定為 Deploy from a branch，分支 `main`、資料夾 `/docs`。

## 使用提醒

- 名單與紀錄保存在目前瀏覽器，不會在不同裝置間同步。
- 主控制台與直播外框請使用同一瀏覽器；在 OBS 使用「視窗擷取」，不要直接將外框網址當成 OBS 瀏覽器來源。
- OCR 在瀏覽器內執行，首次使用需下載 Tesseract 辨識資源；球員姓名需人工確認。Wikipedia 查詢需連網。
- 此版本沒有付費 AI 推薦 API，也不會自動擷取 YouTube 留言。
- 舊版 `teambreak.html` 保留供參考。

## 驗證

```sh
node --test tests/break-random.test.mjs tests/live-scan.test.mjs
```
