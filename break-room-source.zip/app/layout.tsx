import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "BREAK ROOM 團拆控制台",
  description: "隨機分隊、轉盤抽獎、直播特效與球員查詢。",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-Hant">
      <body className="antialiased">{children}</body>
    </html>
  );
}
