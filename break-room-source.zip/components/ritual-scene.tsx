"use client";
import {useEffect,useRef} from 'react';
type V=[number,number,number];
type Face={points:V[];color:number[];pip?:number};
const pipPositions:Record<number,number[][]>={1:[[0,0]],2:[[-.45,-.45],[.45,.45]],3:[[-.45,-.45],[0,0],[.45,.45]],4:[[-.45,-.45],[.45,-.45],[-.45,.45],[.45,.45]],5:[[-.45,-.45],[.45,-.45],[0,0],[-.45,.45],[.45,.45]],6:[[-.45,-.45],[.45,-.45],[-.45,0],[.45,0],[-.45,.45],[.45,.45]]};
function rotate(p:V,angles:V):V{let[x,y,z]=p;const[a,b,c]=angles;[y,z]=[y*Math.cos(a)-z*Math.sin(a),y*Math.sin(a)+z*Math.cos(a)];[x,z]=[x*Math.cos(b)+z*Math.sin(b),-x*Math.sin(b)+z*Math.cos(b)];return[x*Math.cos(c)-y*Math.sin(c),x*Math.sin(c)+y*Math.cos(c),z]}
function cube(value:number):Face[]{const n=.68;const P=(x:number,y:number,z:number):V=>[x*n,y*n,z*n];const sides=[1,2,3,4,5,6].filter(v=>v!==value&&v!==7-value);return [
{points:[P(-1,-1,1),P(1,-1,1),P(1,1,1),P(-1,1,1)],color:[240,237,215],pip:value},
{points:[P(1,-1,-1),P(-1,-1,-1),P(-1,1,-1),P(1,1,-1)],color:[232,228,204],pip:7-value},
{points:[P(1,-1,1),P(1,-1,-1),P(1,1,-1),P(1,1,1)],color:[219,218,196],pip:sides[0]},
{points:[P(-1,-1,-1),P(-1,-1,1),P(-1,1,1),P(-1,1,-1)],color:[219,218,196],pip:7-sides[0]},
{points:[P(-1,-1,-1),P(1,-1,-1),P(1,-1,1),P(-1,-1,1)],color:[249,246,226],pip:sides.find(v=>v!==sides[0]&&v!==7-sides[0])},
{points:[P(-1,1,1),P(1,1,1),P(1,1,-1),P(-1,1,-1)],color:[225,221,201],pip:7-(sides.find(v=>v!==sides[0]&&v!==7-sides[0])||1)}]}
function jiao():Face[]{const faces:Face[]=[];const surface=(i:number,j:number):V=>{const x=i/20*2-1,v=j/8,w=Math.sqrt(Math.max(0,1-x*x));return[x*1.16,(.12+.7*v)*w-.25,.12+.45*Math.sin(v*Math.PI)*w]};for(let i=0;i<20;i++)for(let j=0;j<8;j++){const p=[surface(i,j),surface(i+1,j),surface(i+1,j+1),surface(i,j+1)];faces.push({points:p,color:[167+Math.sin(i*2)*8,43,26]});faces.push({points:p.map(([x,y])=>[x,y,-.12] as V).reverse(),color:[186,65+Math.sin(i)*4,37]})}for(let i=0;i<20;i++)for(const j of [0,8]){const a=surface(i,j),b=surface(i+1,j);faces.push({points:[a,b,[b[0],b[1],-.12],[a[0],a[1],-.12]],color:[110,29,19]})}return faces}
const JIAO=jiao();
export function RitualScene({kind,values,rolling,sequence}:{kind:'dice'|'jiao';values:number[];rolling:boolean;sequence:number}){
 const ref=useRef<HTMLCanvasElement>(null);
 useEffect(()=>{const canvas=ref.current;if(!canvas)return;const ctx=canvas.getContext('2d');if(!ctx)return;let frame=0,start=performance.now();const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 const render=(now:number)=>{const w=canvas.clientWidth||360,h=210,dpr=Math.min(devicePixelRatio||1,2);if(canvas.width!==w*dpr||canvas.height!==h*dpr){canvas.width=w*dpr;canvas.height=h*dpr}ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);const bg=ctx.createRadialGradient(w/2,h*.7,10,w/2,h*.7,w*.65);bg.addColorStop(0,'#33432c');bg.addColorStop(1,'#141e18');ctx.fillStyle=bg;ctx.fillRect(0,0,w,h);ctx.strokeStyle='#a8ca7230';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(w/2,140,w*.43,48,0,0,Math.PI*2);ctx.stroke();
 const t=rolling&&!reduced?Math.min((now-start)/2000,1):1,decay=Math.pow(1-t,2),bounce=rolling&&!reduced?Math.abs(Math.sin(t*Math.PI*3))*Math.pow(1-t,1.5)*66:0;
 for(let i=0;i<2;i++){const value=values[i]??(kind==='dice'?1:0),scale=Math.min(w*.145,49),cx=w*(i===0?.31:.69)+(i===0?-1:1)*Math.sin(t*Math.PI)*16,cy=116-bounce*(i? .86:1);ctx.save();ctx.translate(cx,156);ctx.scale(1, .28);ctx.fillStyle=`rgba(0,0,0,${.42-bounce*.003})`;ctx.shadowColor='#000';ctx.shadowBlur=16;ctx.beginPath();ctx.ellipse(0,0,scale*(1+bounce/150),scale*.72,0,0,Math.PI*2);ctx.fill();ctx.restore();
 const angles:V=[-.28+(kind==='jiao'&&value===0?Math.PI:0)+decay*Math.PI*(i?7:6),.32+decay*Math.PI*5,(i?-.14:.1)+decay*Math.PI*(i?-3:3)];
 const project=(v:V)=>{const p=rotate(v,angles),perspective=6/(6-p[2]);return[cx+p[0]*scale*perspective,cy+p[1]*scale*perspective,p[2]]};const mesh=kind==='dice'?cube(value):JIAO;
 const sorted=mesh.map(f=>({...f,pts:f.points.map(project)})).sort((a,b)=>a.pts.reduce((s,p)=>s+p[2],0)/a.pts.length-b.pts.reduce((s,p)=>s+p[2],0)/b.pts.length);
 for(const f of sorted){const p=f.pts;const normal=(p[1][0]-p[0][0])*(p[2][1]-p[0][1])-(p[1][1]-p[0][1])*(p[2][0]-p[0][0]);if(kind==='dice'&&normal<0)continue;const avgZ=p.reduce((s,v)=>s+v[2],0)/p.length;const light=.83+Math.max(-.2,Math.min(.18,avgZ*.15));const color=f.color.map(v=>Math.min(255,Math.round(v*light)));ctx.fillStyle=`rgb(${color.join(',')})`;ctx.strokeStyle=kind==='dice'?'#777e6355':ctx.fillStyle;ctx.lineWidth=kind==='dice'?1:.6;ctx.lineJoin='round';ctx.beginPath();p.forEach((v,j)=>j?ctx.lineTo(v[0],v[1]):ctx.moveTo(v[0],v[1]));ctx.closePath();ctx.fill();ctx.stroke();
 if(f.pip){for(const[u,v]of pipPositions[f.pip]){const center=f.points[0].map((_,k)=>f.points[0][k]+(f.points[1][k]-f.points[0][k])*(u+1)/2+(f.points[3][k]-f.points[0][k])*(v+1)/2) as V;const poly=Array.from({length:16},(_,k)=>{const a=k/16*Math.PI*2,r=.075;return project(center.map((n,j)=>n+(f.points[1][j]-f.points[0][j])*Math.cos(a)*r+(f.points[3][j]-f.points[0][j])*Math.sin(a)*r) as V)});ctx.fillStyle=f.pip===1?'#b6412b':'#253327';ctx.beginPath();poly.forEach((v,j)=>j?ctx.lineTo(v[0],v[1]):ctx.moveTo(v[0],v[1]));ctx.closePath();ctx.fill()}}}
 ctx.fillStyle='#cfe6b3';ctx.font='14px Arial';ctx.textAlign='center';ctx.fillText(rolling?'投擲中…':values.length?(kind==='dice'?`${value} 點`:value===0?'平面朝上':'凸面朝上'):'待投擲',cx,194);
 }if(rolling&&!reduced&&t<1)frame=requestAnimationFrame(render)};frame=requestAnimationFrame(render);const observer=new ResizeObserver(()=>{if(!rolling)render(performance.now())});observer.observe(canvas);return()=>{cancelAnimationFrame(frame);observer.disconnect()}},[kind,values,rolling,sequence]);
 return <canvas ref={ref} className="ritual-canvas" role="img" aria-label={rolling?'立體投擲動畫':kind==='dice'?`骰子結果：${values.join('、')||'尚未投擲'}`:`筊杯結果：${values.map(v=>v===0?'平面':'凸面').join('、')||'尚未投擲'}`}/>;
}
