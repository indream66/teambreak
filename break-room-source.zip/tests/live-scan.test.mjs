import test from 'node:test';
import assert from 'node:assert/strict';
import {cropFromPoints,pixelCrop,textCandidates} from '../lib/live-scan.ts';
test('crop works in either drag direction',()=>{const a={x:.1,y:.2},b={x:.9,y:.8};assert.deepEqual(cropFromPoints(a,b),cropFromPoints(b,a));assert.deepEqual(pixelCrop(cropFromPoints(a,b),1000,500),{x:100,y:100,width:800,height:300})});
test('crop never reads outside the source frame',()=>{assert.deepEqual(pixelCrop({x:.9,y:.9,width:2,height:2},100,100),{x:90,y:90,width:10,height:10});assert.deepEqual(pixelCrop({x:0,y:0,width:1,height:1},1920,1080),{x:0,y:0,width:1920,height:1080});assert.throws(()=>pixelCrop({x:0,y:0,width:1,height:1},0,0));const box=cropFromPoints({x:-1,y:3},{x:1,y:-1});assert.deepEqual(box,{x:0,y:0,width:1,height:1})});
test('candidate lines are deduplicated and do not fabricate identities',()=>{assert.deepEqual(textCandidates('PENNY HARDAWAY\n12345\nPENNY HARDAWAY\nLuka Dončić\n!'),['PENNY HARDAWAY','Luka Dončić']);assert.deepEqual(textCandidates('1234\n!!'),[]);assert.equal(textCandidates(Array.from({length:15},(_,i)=>'Candidate '+String.fromCharCode(65+i)).join('\n')).length,10)});
