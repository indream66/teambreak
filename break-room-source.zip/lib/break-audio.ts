let generation=0;
let context:AudioContext|null=null;let master:GainNode|null=null;const playing=new Set<AudioScheduledSourceNode>();
export function unlockAudio(){if(!context||context.state==='closed'){context=new AudioContext();master=context.createGain();const limiter=context.createDynamicsCompressor();limiter.threshold.value=-12;limiter.knee.value=8;limiter.ratio.value=8;master.connect(limiter);limiter.connect(context.destination)}return context.resume()}
function stopSources(){for(const n of playing){try{n.stop()}catch{}}playing.clear()}
export function stopAudio(){generation++;stopSources()}
export function audioVolume(value:number){if(context&&master)master.gain.setTargetAtTime(Math.max(0,Math.min(1,value)),context.currentTime,.02)}
export async function playCue(kind:string,volume=.6){const ticket=++generation;await unlockAudio();if(ticket!==generation)return;stopSources();const c=context!,out=master!,base=c.currentTime+.02;audioVolume(volume);
 const track=(n:AudioScheduledSourceNode)=>{playing.add(n);n.onended=()=>{playing.delete(n);n.disconnect()}};
 const tone=(f:number,t:number,d:number,g=.14,type:OscillatorType='sine',end?:number)=>{const o=c.createOscillator(),a=c.createGain();o.type=type;o.frequency.setValueAtTime(f,base+t);if(end)o.frequency.exponentialRampToValueAtTime(end,base+t+d);a.gain.setValueAtTime(.0001,base+t);a.gain.exponentialRampToValueAtTime(g,base+t+.012);a.gain.exponentialRampToValueAtTime(.0001,base+t+d);o.connect(a);a.connect(out);track(o);o.start(base+t);o.stop(base+t+d+.03)};
 const noise=(t:number,d:number,g:number,frequency:number)=>{const b=c.createBuffer(1,Math.ceil(c.sampleRate*d),c.sampleRate),a=b.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=(Math.random()*2-1)*(1-i/a.length);const n=c.createBufferSource(),filter=c.createBiquadFilter(),v=c.createGain();n.buffer=b;filter.type='bandpass';filter.frequency.value=frequency;filter.Q.value=.7;v.gain.setValueAtTime(g,base+t);v.gain.exponentialRampToValueAtTime(.0001,base+t+d);n.connect(filter);filter.connect(v);v.connect(out);track(n);n.start(base+t);n.stop(base+t+d)};
 if(kind==='win'){[523,659,784,1047].forEach((f,i)=>{tone(f,i*.16,.52,.19,'triangle');tone(f*2,i*.16+.05,.35,.05)});[523,659,784].forEach(f=>tone(f,.7,1.1,.10,'triangle'));[.15,.75,1.3].forEach(t=>{noise(t,.32,.5,2800);tone(90,t,.2,.16,'sine',35)})}
 else if(kind==='fire'){tone(45,0,1.7,.42,'sine',28);tone(100,0,.7,.18,'sawtooth',700);noise(.05,.85,.65,800);[.65,.86,1.1].forEach(t=>{tone(220,t,.32,.16,'sawtooth',165);tone(330,t,.32,.13,'square');noise(t,.12,.25,2500)})}
 else if(kind==='lose'){[392,370,330,196].forEach((f,i)=>{tone(f,i*.24,i===3?.85:.26,.16,'sawtooth',i===3?78:f*.97);tone(f*.5,i*.24,.25,.09,'triangle')});tone(520,1.55,.45,.12,'sine',90)}
 else if(kind==='drum'){for(let i=0;i<24;i++){const t=2.6*(1-Math.pow(1-i/24,1.6));noise(t,.075,.13+i*.01,2200);tone(155,t,.055,.12,'triangle',90)}tone(60,2.65,.75,.4,'sine',28);noise(2.65,1,.45,4200)}
 else if(kind==='dice'){[.08,.25,.47,.74,1.06,1.4,1.7].forEach((t,i)=>{noise(t,.055,.28-i*.025,1800);tone(850-i*55,t,.07,.13-i*.01,'triangle',330)})}
 else if(kind==='jiao'){[.13,.54,1.05,1.55].forEach((t,i)=>{tone(430-i*55,t,.14,.24-i*.03,'triangle',170);noise(t,.06,.18,950)})}
}
