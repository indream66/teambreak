export type Crop={x:number;y:number;width:number;height:number};
const clamp=(n:number)=>Math.max(0,Math.min(1,Number.isFinite(n)?n:0));
export function cropFromPoints(a:{x:number;y:number},b:{x:number;y:number}):Crop{
 const x=Math.min(clamp(a.x),clamp(b.x)),y=Math.min(clamp(a.y),clamp(b.y));
 return {x,y,width:Math.abs(clamp(a.x)-clamp(b.x)),height:Math.abs(clamp(a.y)-clamp(b.y))};
}
export function pixelCrop(c:Crop,w:number,h:number){
 if(w<1||h<1)throw Error('畫面尚未準備完成');const x=Math.min(w-1,Math.floor(clamp(c.x)*w)),y=Math.min(h-1,Math.floor(clamp(c.y)*h));
 return {x,y,width:Math.max(1,Math.min(w-x,Math.round(clamp(c.width)*w))),height:Math.max(1,Math.min(h-y,Math.round(clamp(c.height)*h)))};
}
export function textCandidates(text:string){return [...new Set(text.split('\n').map(s=>s.replace(/[^A-Za-zÀ-ž.'’ -]/g,' ').replace(/\s+/g,' ').trim()).filter(s=>s.length>=3&&s.length<=70&&/[A-Za-z]{2}/.test(s)))].slice(0,10)};
let engineLoad:Promise<any>|null=null;
export function loadOcr(){
 if((window as any).Tesseract)return Promise.resolve((window as any).Tesseract);
 if(engineLoad)return engineLoad;
 engineLoad=new Promise((resolve,reject)=>{const script=document.createElement('script');const timeout=setTimeout(()=>{script.remove();engineLoad=null;reject(Error('文字辨識模型載入逾時，請重試。'))},30000);script.src='https://cdn.jsdelivr.net/npm/tesseract.js@6.0.1/dist/tesseract.min.js';script.onload=()=>{clearTimeout(timeout);resolve((window as any).Tesseract)};script.onerror=()=>{clearTimeout(timeout);script.remove();engineLoad=null;reject(Error('無法載入文字辨識模型，請檢查網路。'))};document.head.append(script)});return engineLoad;
}
