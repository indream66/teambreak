export type NextInt = (n: number) => number;
export type Assignment = { prize: string; name: string };
export function rand(n: number) {
  if (!Number.isInteger(n) || n < 1 || n > 4294967296) throw new Error('無效的隨機範圍');
  const a = new Uint32Array(1), limit = Math.floor(4294967296 / n) * n;
  do { crypto.getRandomValues(a); } while (a[0] >= limit);
  return a[0] % n;
}
export function shuffle<T>(input: T[], next: NextInt = rand): T[] {
  const result = [...input];
  for (let i = result.length - 1; i > 0; i--) { const j = next(i + 1); [result[i], result[j]] = [result[j], result[i]]; }
  return result;
}
export function validateRounds(rounds: number) {
  if (!Number.isInteger(rounds) || rounds < 1 || rounds > 100) throw new Error('隨機次數需介於 1 至 100');
}
export function prizePool(names: string[], repeat: boolean) {
  const clean = names.map(n => n.trim()).filter(Boolean);
  return repeat ? clean : [...new Set(clean)];
}
export function prizeRound(names: string[], prizes: string[], repeat: boolean, next: NextInt = rand): Assignment[] {
  const pool = prizePool(names, repeat);
  if (!pool.length || !prizes.length || prizes.length > 100) throw new Error('請加入參加者與 1–100 個獎項');
  if (!repeat && prizes.length > pool.length) throw new Error('獎項多於不重複人數，請減少獎項或允許重複中獎');
  const order = repeat ? [] : shuffle(pool, next);
  return prizes.map((prize, i) => ({ prize, name: repeat ? pool[next(pool.length)] : order[i] }));
}
export function diceRoll(next: NextInt = rand) {
  const values = [next(6) + 1, next(6) + 1]; return { values, total: values[0] + values[1] };
}
export function jiaoRoll(next: NextInt = rand) {
  const faces = [next(2), next(2)];
  return { faces, label: faces[0] !== faces[1] ? '聖筊' : faces[0] === 0 ? '笑筊' : '陰筊' };
}
export function randomItems(items:string[], names:string[], linked:boolean, next:NextInt=rand):string[]{
 if(!items.length||items.length>100)throw Error('請輸入 1–100 個項目');
 if(linked&&items.length!==names.length)throw Error('項目數量需與參加名額相同');
 return shuffle(items,next).map((item,i)=>linked?`${names[i]} → ${item}`:`${i+1}. ${item}`);
}
